'''
n = int(inpuenter t("the number="))

i=1000

while(i>=n):
    
    print(i)
    
    i = i-1
'''
'''
n = int(input("enter the number="))  #factorial 

i=1
fact=1
while(i<=n):
    fact = fact*i
    i+=1
    
print("factorial is", fact)
'''
'''
for i in range(1,7):#row
    for j in range(i):
        
        print(" ", end= "")
        
    for k in range(1,7-i):#column
        print("*", end ="")
    
    print()
'''
'''
n = int(input('enter the numbers ='))
prime = 0
for i in range(1,n+1):
    if n%i == 0:
        print('prime number is there')

if prime == 0:
    print('it is prime no')

else:
    print('it is not prime number')
''' 

# Factorial number
'''
n = int(input('enter the numbers ='))
n1=0
n2=1
print(n1)
print(n2)
for i in range(3,n+1):
    n3=n2+n1
    print('addition is:',n3)

    n1 = n2
    n2 = n3
'''

# right traingle
'''
for i in range(1,6):
    print(" "*(6-i),"*"*i)
    
'''
for i in range(1,6):
    print("*"*i)