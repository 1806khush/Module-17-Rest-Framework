d = {}

while True:
    menu = """
    Press 1 for Signup
    Press 2 for Login
    Press 3 for Forgot Password
    Press 4 to Exit
    """
    print(menu)

    try:
        choice = int(input("Enter a choice: "))
    except ValueError:
        print("Invalid input! Please enter a number between 1 and 4.")
        continue

    if choice == 1:
        print("Welcome to Signup")
        name = input("Enter name: ")
        email = input("Enter email: ")
        mobile = input("Enter mobile number: ")
        password = input("Enter password: ")
        confirm_password = input("Confirm password: ")

        if password == confirm_password:
            d['name'] = name
            d['email'] = email
            d['mobile'] = mobile
            d['password'] = password
            print("Signup successful!")
        else:
            print("Password and confirm password do not match!")

    elif choice == 2:
        print("Welcome to Login")
        email = input("Enter email: ")
        password = input("Enter password: ")

        if d.get('email') == email:
            if d.get('password') == password:
                print("Login successful!")
                break
            else:
                print("Incorrect password!")
        else:
            print("Email does not exist!")


