#map 
'''
def double(n):
    return n*2
n  = [1,3,4,2,6]
result = map(double,n)
print(list(result))

#filter
def double(n):
    return n%2==0
n  = [1,3,4,2,6]
result = filter(double,n)
print(list(result))


'''

#O.O.P.S

#OBJECT ORIENTED PROGRAMMING SYSTEM
'''
1] CLASS AND OBJECT
2]INHERITENCE
3]POLYMORPHISM
4]DATA ENCAPSULATION
5]ABSTRACTION


1]CLASS & ABJECT

-> CLASS  -  class is a collection of data member and member functions

acess specifiers :
public      : a=10
private     : _a = 10
protected   :__a = 10


'''
'''

class A:
    
    def fun1(self):
        print("this is function 1 :")
    
    def fun2(self):
        print("this is function 2 :")
        
    def fun3(self):
        print("this is function 3 :")

obj = A()
obj.fun1()
obj.fun2()
obj.fun3()



'''

class A :
    def fun1(self):
        l = ["grape","orange","pineapple"]
        print(l)

    def fun2(self):
        n = int(input("Enter No Of Rows : "))

        for i in range(1,n+1):
            print("*"*i)
    
    def fun3(self):
        d = {1:"how",2:"are",3:"You",4:"bittu"}
        print(d)

    def fun4(self):
        n = int(input("Enter Number : "))
        n1 = 0
        n2 = 1

        print(n1)
        print(n2)

        for i in range(3,n+1):
            n3=n1+n2
            print(n3)
            n1=n2
            n2=n3

obj = A()
while True:
    menu = """
    press 1 list!!
    press 2 pattern!!
    press 3 dictionary!!
    press 4 fibbonacci!!
    press 5 Exit!!
    """
    print(menu)
    choice = int(input("Enter Your Choice : "))
    if choice == 1:
        obj.fun1()

    elif choice == 2:
        obj.fun2()

    elif choice == 3:
        obj.fun3()

    elif choice == 4:
        obj.fun4()

    elif choice == 5:
        print("Thnak You!!")
        break

    else:
        print("Invalid Choice!!")