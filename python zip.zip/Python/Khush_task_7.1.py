from Khush_task_7 import *
menu = """
press 1 for Pattern!!
press 2 for Reversed pattern !!
press 3 for Mid Of String!!
press 4 Palindrom!!
press 5 Exit!!

"""
while True:
    print(menu)
    choice = int(input("Enter Choice : "))
    if choice == 1:
        n = int(input("Enter Number : "))
        fun1(n)

    elif choice == 2:
        fun2()

    elif choice == 3:
        fun3()   

    elif choice == 4 :
        fun4()

    elif choice == 5:
        print("Thank You!!")
        break 

    else:
        print("Invalid!!")
        break
   
