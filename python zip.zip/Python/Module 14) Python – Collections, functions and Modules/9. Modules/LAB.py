#Lab:
# Write a Python program to import the math module and use functions like sqrt(), ceil(), floor().

import math

number = 16
print("Square root of", number, "is:", math.sqrt(number))

print("Ceiling value of 3.7 is:", math.ceil(3.7))

print("Floor value of 3.7 is:", math.floor(3.7))

#Write a Python program to generate random numbers using the random module.

import random


print("Random float between 0 and 1:", random.random())

print("Random integer between 1 and 100:", random.randint(1, 100))

#23) Write a Python program to demonstrate the use of functions from the math module. 

import math

# Using sqrt() to calculate square root
number = 55
print("Square root of", number, "is:", math.sqrt(number))

# Using ceil() to round up
print("Ceiling value of 5.3 is:", math.ceil(5.3))

# Using floor() to round down
print("Floor value of 5.3 is:", math.floor(5.7))

# 24) Write a Python program to generate random numbers between 1 and 100 using the random module.

import random

print("Random integer between 1 and 100:", random.randint(1, 100))
