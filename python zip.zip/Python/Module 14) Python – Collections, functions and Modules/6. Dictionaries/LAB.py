#Lab:
# Write a Python program to create a dictionary with 6 key-value pairs.


my_dict = {
    "name": "Khush",
    "age": 20,
    "course": "Information Technology",
    "city": "Ahmedabad",
    "grade": "A",
    "university": "Indus University"
}
print("Dictionary:", my_dict)

# Write a Python program to access values using dictionary keys.



print("Name:", my_dict["name"])  
print("City:", my_dict["city"]) 

#13) Write a Python program to create a dictionary of 6 key-value pairs.

my_dict = {
    "name": "Khush",
    "age": 20,
    "course": "Information Technology",
    "city": "Ahmedabad",
    "grade": "A",
    "university": "Indus University"
}
print("Dictionary:", my_dict)

#14) Write a Python program to access values using keys from a dictionary.

print("Name:", my_dict["name"])
print("University:", my_dict["university"])
