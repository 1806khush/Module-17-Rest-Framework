
# • Write a Python program to create a tuple with multiple data types.

tuples = (1, "Hello", 3.14, True, [1, 2, 3], {"key": "value"})
print("Tuple with multiple :", tuples)

# • Write a Python program to concatenate two tuples.


tuple1 = (1, 2, 3)
tuple2 = ("a", "b", "c")
concatenated_tuple = tuple1 + tuple2
print("Concatenated tuple:", concatenated_tuple)

# 7) Write a Python program to convert a list into a tuple. 

# Converting a list into a tuple
sample_list = [10, 20, 30, 40]
converted_tuple = tuple(sample_list)
print("Converted tuple:", converted_tuple)


# 8) Write a Python program to create a tuple with multiple data types. 


sample_tuple = (100, 200, 300, 400)
first_value = sample_tuple[0]
print("Value at the first index:", first_value)

# 9) Write a Python program to concatenate two tuples into one.

tuple1 = (1, 2, 3)
tuple2 = ('a', 'b', 'c')
concatenated_tuple = tuple1 + tuple2
print("Concatenated Tuple:", concatenated_tuple)

# 10) Write a Python program to access the value of the first index in a tuple.

sample_tuple = (100, 200, 300, 400)

first_value = sample_tuple[0] 
print("Value at first :", first_value)






