# ABSTRACTION ->    DATA HIDING

#ABC STANDS FOR -> ABSTRACT BASE CLASS


'''
from abc import ABC

class A(ABC):
    def fun1(self):
        pass
    
class B(A):
    def fun1(self):
        print("car has 4 wheels")
        
class C(A):
    def fun1(self):
        print("car has 6 wheels")
        
obj = B()
obj.fun1()

obj = C()
obj.fun1()

'''

import random
from abc import ABC

class Employer(ABC):
    
    def get_salary(self):
        pass

class Employee1(Employer):
    
    def get_salary(self):
        salary = random.randint(40000, 60000)
        print(f"Employee1 salary of {salary}.")

class Employee2(Employer):
    
    def get_salary(self):
        salary = random.randint(70000, 90000)
        print(f"Employee2  salary of {salary}.")

class Employee3(Employer):
    
    def get_salary(self):
        salary = random.randint(90000, 110000)
        print(f"Employee3 salary of {salary}.")

obj1 = Employee1()
obj1.get_salary()

obj2 = Employee2()
obj2.get_salary()

obj3 = Employee3()
obj3.get_salary()

        