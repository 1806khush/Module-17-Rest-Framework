def fun1(n):

    
     n = int(input("Enter No Of Rows : "))

     for i in range(1,n+1):
        print( f"{i}"* i)

def fun2():
    n = int(input("Enter No Of Rows : "))
    ch=0 
    for i in range(1,n+1): 
        for j in range(1,i+1):
            print(chr(ch+65)+"",end="")
            if ch < 25:
                ch +=1
            else:
                ch=0
        print()
        
def fun3():
    s = input("Enter String: ")

    if len(s) % 2 == 0:  # Check if the string length is even
        print(s)
    else:
        mid = int(len(s) / 2)  # Find the middle index
        print(s[mid - 1] + s[mid] + s[mid + 1])  # Print 3 characters centered at the middle

def fun4():
    s = input("Enter String : ")
    
    if s[::-1] == s:
         print("Palindron!!")
    else:
         print("Not Palindrom")
         
         