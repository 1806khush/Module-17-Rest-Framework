#INHERITANCE
#1-> SINGLE INHERTANCE 
    #A->B (PARENT -> ROOT)
'''class A:
    def fun1(self):
        print("hi khush")

class B(A):
    def fun2(self):
        print("hi bittu")
        
obj = B()
obj.fun1()
obj.fun2()    
'''
#2) multilevel
   # A->B->C

class A:
    def fun1(self):
        print("hi khush")

class B(A):
    def fun2(self):
        print("hi bittu")
class C(B):
    def fun3(self):
        print("hello there")
        
obj = C()
obj.fun1()
obj.fun2()   
obj.fun3()  