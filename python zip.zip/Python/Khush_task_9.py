
'''
import instaloader

username = input("Enter Username : ")
ig = instaloader.Instaloader()
profile = instaloader.Profile.from_username(ig.context,username)

print("Username : ",profile.username)
print("Post : ",profile.mediacount)
print("Followers : ",str(profile.Followers))
print("Following : ",str(profile.Following))
print("Bio : ",profile.biography)
instaloader.Instaloader().download_profile(username,Profile_pic_only=True)

'''
'''
import random
print("Welcome No Gussing Game!!")
print("Enter Gusses No 1 to 100")

r = random.randint(1,100)

while True:
    n = int(input("Enter Your Guess No : "))
    
    if n>r:
        print("Guess No Is High!!")

    elif n<r:
        print("Guess No Is Low!!")

    elif n==r:
        print("Your Guess Is Right!!")
        break

    else:
        print("Invalid No!!")
'''


import random
l1 = ["ROCK","PAPER","SCISSOR"]

while True:
    menu = """
    press 1 for ROCK
    press 2 for PAPER
    press 3 for SCISSOR

    """
    print(menu)
    choice = int(input("Enter Choice : "))
    r = random.choice(l1)
    if choice == 1 and r == "SCISSOR":
        print(r)
        print("User Win!!")
    
    elif choice == 2 and r == "ROCK":
        print(r)
        print("User Win!!")
    
    elif choice == 3 and r == "PAPER":
        print(r)
        print("User Win!!")
    
    elif choice == 1 and r == "Rock":
        print(r)
        print("Drop!1")
    
    elif choice == 2 and r == "SCISSOR":
        print(r)
        print("Drop!1")

    elif choice == 3 and r == "PAPER":
        print(r)
        print("Draw!!")
    
    else:
        print("Computer Win!!")
        
