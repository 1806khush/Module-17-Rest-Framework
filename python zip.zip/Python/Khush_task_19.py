import pymysql

mydb = pymysql.connect(host = "localhost", user = "root", password = "")
mycursor = mydb.cursor()

mycursor.execute("create database if not exists python2")
mydb.commit()

mydb = pymysql.connect(host = "localhost", user = "root", password = "", database = "python1")
mycursor = mydb.cursor()

mycursor.execute("create table if not exists signup(id int primary key auto_increment,username varchar(80),password varchar(80))")
mydb.commit()

