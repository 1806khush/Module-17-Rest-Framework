# files and exception handling
'''
file = open("text.txt","w")
file.write("hi this is me!")
file.close()



##################################



file = open("text1.txt","w+")
file.write("hiiiiiiii thereeee")
print(file.tell())
file.seek(0)
print(file.readline())
file.close


file = open("C:\\Users\\khush\\OneDrive\\Documents\\Python\\text1.txt","r+")
file.write("hiiiiiiii thereeee")
print(file.readline())
file.close()
'''
'''
try:
    n = int(input('enter no 1 :'))
    n1 = int(input('enter no 2 :'))
    print(" addition is :",n+n1)
    
except ValueError as e:
    print(e)

else:
    print("try block executedd")
    
finally:
    print("all executed")
'''

try:
    n = int(input('enter no 1 :'))
    n1 = int(input('enter no 2 :'))
    print(" division is :",n/n1)
    
except ValueError as e:
    print(e)

except ZeroDivisionError as e:
    print(e)
    
else:
    print("try block executedd")
    
finally:
    print("all executed")
    