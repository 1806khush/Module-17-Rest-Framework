
questions = {}




def add_question():
    question_id = input("Enter question ID: ")
    if question_id in questions:
        print("Question ID already exists!")
        return
    
    question = input("Enter the question: ")
    
    options = {
        "A": input("Option A: "),
        "B": input("Option B: "),
        "C": input("Option C: "),
    }
    answer = input("Enter the correct answer (A/B/C): ")
    
    if answer not in options:
        print("Invalid answer. Please try again.")
        return
    
    
    questions[question_id] = {"question": question, "options": options, "answer": answer}
    
    print("Question added successfully!")





def view_questions():
    
    
    if not questions:
        print("No questions available.")
        return
    
    
    for qid, qdata in questions.items():
        print(f"ID: {qid}, Question: {qdata['question']}")
        
        
        for option, text in qdata['options'].items():
            
            print(f"{option}: {text}")
            
        print(f"Answer: {qdata['answer']}")
        


def delete_question():
    
    
    question_id = input("Enter the question ID to delete: ")
    
    if question_id in questions:
        confirmation = input("Are you sure you want to delete the question: (Y/N): ",question_id).upper()
        
        if confirmation == 'Y':
            
            del questions[question_id]
            print("Question deleted successfully!")
            
        else:
            print("Deletion cancelled.")
            
    else:
        print("Question ID not found.")


def take_quiz():
    
    
    if not questions:
        print("No questions available.")
        return
    
    score = 0
    
    for qid, qdata in questions.items():
        
        print("Question:", qdata["question"])

        for option, text in qdata["options"].items():
            print(option, ":", text)

            
            
        answer = input("Your answer (A/B/C): ").upper()
        
        if answer == qdata['answer']:
            score += 1
            
    print("Your score is : ",score/{len(questions)})


def main_menu():
    
    while True:
        
        menu = """
        Select your Role:
        1. Quiz Master
        2. Quiz Cracker
        3. Exit
        """
        print(menu)

        try:
            choice1 = int(input("Enter your choice: "))
            
        except ValueError:
            
            print("Invalid input! Please enter a number.")
            
            continue

        if choice1 == 1:
            
            while True:
                menu1 = """
                1. Add Question
                2. View Questions
                3. Delete Question
                4. Back to Main Menu
                """
                print(menu1)

                choice = input("Enter your choice: ")

                if choice == '1':
                    add_question()
                elif choice == '2':
                    view_questions()
                elif choice == '3':
                    delete_question()
                elif choice == '4':
                    break
                else:
                    print("Invalid choice. Please try again.")

        elif choice1 == 2:
            take_quiz()

        elif choice1 == 3:
            print("Exiting the program.")
            break

        else:
            print("Invalid choice! Please enter a valid option.")


if __name__ == "__main__":
    main_menu()
