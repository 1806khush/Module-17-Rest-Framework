import pymysql

try:
    mydb = pymysql.connect(host="localhost", user="root", password="")
    mycursor = mydb.cursor()
    mycursor.execute("CREATE DATABASE IF NOT EXISTS python2")
    mydb.commit()

    mydb = pymysql.connect(host="localhost", user="root", password="", database="python2")
    mycursor = mydb.cursor()

    
    mycursor.execute("""
        CREATE TABLE IF NOT EXISTS signup (
            id INT PRIMARY KEY AUTO_INCREMENT,
            username VARCHAR(80) UNIQUE,
            password VARCHAR(80)
            
        )
    """)
    mydb.commit()

except pymysql.Error as e:
    print(f"Database connection failed: {e}")

class Signup:
    
    
    def register(self):
        
        
        username = input("Enter username: ")
        password = input("Enter password: ")
    

        
        mycursor.execute("SELECT * FROM signup WHERE username = %s", (username,))
        existing_user = mycursor.fetchone()

        if existing_user:
            
            print("Username already exists! Try another.")
            
        else:
            
            try:
                
                mycursor.execute("INSERT INTO signup (username, password) VALUES (%s, %s)", (username, password))
                mydb.commit()
                
                print("Signup successful!")
                
            except pymysql.Error as e:
                
                print(f"Error inserting data: {e}")

class Login:
    
    
    
    def login(self):
        
        
        username = input("Enter username: ")
        password = input("Enter password: ")
        confirm_pass = input("Enter confirm password: ")
        
        
        if confirm_pass == password:
            print("Authenticated!!")
        else:
            print("error!!")
            

        mycursor.execute("SELECT * FROM signup WHERE username = %s AND password = %s", (username, password))
        user = mycursor.fetchone()

        if user:
            print("Login successful! Welcome,", username)
        else:
            print("Invalid credentials! Please try again.")

class UserAuth(Signup, Login):
    pass

auth = UserAuth()

while True:
    
    print("\nChoose an option:")
    print("1. Signup")
    print("2. Login")
    print("3. Fetch data")
    print("4. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        auth.register()
        
        
    elif choice == "2":
        auth.login()
        
        
        
    elif choice == "3":
        
        query = "select * from signup"
        
        mycursor.execute(query)
        
        data = mycursor.fetchall()
        print(data)
        
        print("Data fetched!!!")    
        
        
    elif choice == "4":
        
        
        print(" Thank you! Exiting...")
        break
    
    else:
        
        print(" Invalid choice! Please try again.")

