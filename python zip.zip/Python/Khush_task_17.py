import random

class Create_acc:
    def account(self):
        name = input("Enter your Name: ")
        mobileno = int(input("Enter your Mobile Number: "))
        email_id = input("Enter your email Id: ")
        age = int(input("Enter your age: "))
        password = input("Enter your account password: ")
        ac_no = random.randint(100, 1000)

        print(f"Your account number is: {ac_no}")

        balance = 5000
        self.name = name
        self.age = age
        self.ac_no = ac_no
        self.balance = balance
        self.password = password
        return self

class Login:
    def __init__(self, account):
        self.account = account

    def login(self):
        print("******* Welcome to login page!! *******")

        confirm_acc_no = int(input("Enter your Account number: "))
        confirm_password = input("Enter your account password: ")

        try:
            if confirm_acc_no == self.account.ac_no and confirm_password == self.account.password:
                print(f"Login successful! Welcome, {self.account.name}.")

                while True:
                    menu = """
                    Press 1 for Deposit money to your account 
                    Press 2 for Withdraw money from your account
                    Press 3 for Show current balance of your account
                    Press 4 to Exit
                    """
                    print(menu)

                    choice = int(input("Enter your choice: "))

                    if choice == 1:
                        print("Welcome to deposit section!")
                        amount_deposit = int(input("Enter the amount you want to deposit in your account: "))
                        self.account.balance += amount_deposit
                        print("Your new balance is:", self.account.balance)

                    elif choice == 2:
                        print("Welcome to withdraw section!")
                        amount_withdraw = int(input("Enter the amount you want to withdraw from your account: "))

                        if amount_withdraw > self.account.balance:
                            print("Insufficient balance! Your account does not have enough funds.")
                        else:
                            self.account.balance -= amount_withdraw
                            print("Your new balance after withdrawal is:", self.account.balance)

                    elif choice == 3:
                        print("Your current account balance is:", self.account.balance)

                    elif choice == 4:
                        print("Thank you for using our service. Goodbye!")
                        break

                    else:
                        print("Invalid choice! Please try again.")

            else:
                print("Login unsuccessful! Invalid credentials.")

        except Exception as e:
            print("Error:", e)

account_instance = Create_acc().account()
login_instance = Login(account_instance)
login_instance.login()
