#ENCAPSULATION
# DATA BIDING INTO A SINGLE ENTITY IS CALLED ENCAPSULATION
# POINTER   -   SECOND VARIABLE -> ADDRESS

# self.b = a



class hospital:
    
    def register(self):
        print("********************     Welcome to Zydus Hospital Catalogue    ***********************")
        
        try:
            c_id = int(input("Enter Patient's Case Id (a number): "))
            if c_id <= 0:
                raise ValueError("Case ID must be a positive number.")
        except ValueError as e:
            print(f"Invalid input for Case ID: {e}")
            return
        
        pname = input("Enter patient's name: ")
        if not pname.isalpha():
            print("Invalid input for patient's name. It must contain only letters.")
            return
        
        doctor = input("Enter your allocated doctor's name: ")
        if not doctor.isalpha():
            print("Invalid input for doctor's name. It must contain only letters.")
            return
        
        try:
            age = int(input("Enter your age: "))
            if age <= 0 or age > 120:
                raise ValueError("Age must be a positive number and realistic (0-120).")
        except ValueError as e:
            print(f"Invalid input for age: {e}")
            return
        
        desease = input("Enter the disease the patient has: ")
        if not desease.isalpha():
            print("Invalid input for disease. It must contain only letters.")
            return
        
        print("Registered Successfully!!!")
        # Assigning values to instance variables
        self.c_id = c_id
        self.age = age
        self.desease = desease
        self.doctor = doctor
        self.pname = pname
            
    
    def eregister(self):
        
        acid = int(input("Enter case Id : "))
        
        try:
            if self.c_id == acid:
                print("Your old case report is : ",self.desease)
                desc = input("Enter progress for the case :")
                
                
                self.desc = desc
                
            else:
                
                print("Case Id does not exists!!!")
                
        except:
            
            print("Case Id does not exists!!!")
        
    def show_info(self):
        try:
            
            print("Your Name is  :",self.pname)
            print("CASE Id is :  ",self.c_id)
            print("Old Report is :  ",self.desease)
            print("New progress Report is  :",self.desc)
            print("Your Age is  :",self.age)
        
        except:
            print("All list completed!!")
            
            
obj  = hospital()

status = True

while status:
    menu = """
    press 1 for New Registration  
    press 2 for Already Registered
    press 3 for Patient's information 
    press 4 for Exit  
    
"""
    print(menu)
    
    choice = int(input("Enter your choice :"))
    
    if choice == 1:
        obj.register()
    elif choice == 2:
        obj.eregister()
    
    elif choice == 3:
        obj.show_info()
    
    elif choice ==4:
        status = False
        
    else:
        print("You have entered invalid option!!!!!")
        break