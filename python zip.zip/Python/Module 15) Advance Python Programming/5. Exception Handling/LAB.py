# Write a Python program to handle exceptions in a simple calculator (division by zero, invalid input).

try:
    num1 = float(input("Enter first number: "))
    num2 = float(input("Enter second number: "))
    result = num1 / num2  # May raise ZeroDivisionError
    print("Result:", result)
except ZeroDivisionError:
    print("Error: Division by zero is not allowed.")
except ValueError:
    print("Error: Invalid input! Please enter numeric values.")


# Write a Python program to demonstrate handling multiple exceptions.
try:
    # Attempting to open a non-existent file
    with open("non_existent_file.txt", "r") as file:
        content = file.read()
    
    # Performing division
    num = int(input("Enter a number: "))
    result = 100 / num  # May raise ZeroDivisionError
    print("Result:", result)
except FileNotFoundError:
    print("Error: The file was not found.")
except ZeroDivisionError:
    print("Error: Cannot divide by zero.")
except ValueError:
    print("Error: Please enter a valid number.")


#Practical Examples: 7) Write a Python program to handle exceptions in a calculator.
try:
    file = open("example.txt", "r")  # Attempt to open a file
    content = file.read()
    print("File Content:", content)
except FileNotFoundError:
    print("Error: The file does not exist.")
finally:
    if 'file' in locals() and not file.closed:
        file.close()
        print("File has been closed.")


# 8) Write a Python program to handle multiple exceptions (e.g., file not found, division by zero).

class NegativeNumberError(Exception):
    """Custom exception for negative numbers."""
    pass
1
try:
    num = int(input("Enter a positive number: "))
    if num < 0:
        raise NegativeNumberError("Negative numbers are not allowed!")
    print("Valid input:", num)
except NegativeNumberError as e:
    print("Error:", e)
except ValueError:
    print("Error: Please enter a valid integer.")


