#Write a Python program to read the contents of a file and print them on the console.

# Open the file in read mode
with open("example.txt", "r") as file:
    content = file.read()  # Read the entire file content
    print("File Content:\n", content)  # Print the file data


#Write a Python program to write multiple strings into a file.

# Open the file in write mode
with open("example.txt", "w") as file:
    lines = ["This is the first line.\n", "This is the second line.\n", "This is the third line.\n"]
    file.writelines(lines)  # Writing multiple lines

print("Multiple lines have been written to the file.")



#Practical Examples: 4) Write a Python program to create a file and print the string into the file. 

# Open the file in write mode
with open("myfile.txt", "w") as file:
    file.write("This is a new file with a sample string.")

print("File 'myfile.txt' has been created and a string has been written.")


#5) Write a Python program to read a file and print the data on the console. 

# Open the file in read mode
with open("myfile.txt", "r") as file:
    print("File Content:\n", file.read())  # Reading and printing the file content



# 6) Write aPython program to check the current position of the file cursor using tell().

# Open the file in read mode
with open("myfile.txt", "r") as file:
    print("Initial Cursor Position:", file.tell())  # Cursor position before reading
    content = file.read(10)  # Read the first 10 characters
    print("After Reading 10 Characters, Cursor Position:", file.tell())  # Cursor position after reading


