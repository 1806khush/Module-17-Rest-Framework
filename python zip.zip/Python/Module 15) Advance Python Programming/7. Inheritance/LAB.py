# Write Python programs to demonstrate different types of inheritance (single, multiple,multilevel, etc.).
class Animal:
    def speak(self):
        return "Animal speaks"

class Dog(Animal):
    def bark(self):
        return "Dog barks"

# Creating an object
dog = Dog()
print(dog.speak())  # Inherited method
print(dog.bark())   # Own method

#multilevel


class Animal:
    def speak(self):
        return "Animal speaks"

class Mammal(Animal):
    def walk(self):
        return "Mammal walks"

class Dog(Mammal):
    def bark(self):
        return "Dog barks"

# Creating an object
dog = Dog()
print(dog.speak())  # From Animal class
print(dog.walk())   # From Mammal class
print(dog.bark())   # From Dog class


# multiple

class Father:
    def skill(self):
        return "Father is good at coding"

class Mother:
    def hobby(self):
        return "Mother loves painting"

class Child(Father, Mother):
    def talent(self):
        return "Child is creative"

# Creating an object
child = Child()
print(child.skill())  # From Father
print(child.hobby())  # From Mother
print(child.talent()) # From Child



#Practical Examples: 13) Write a Python program to show single inheritance. 
class Vehicle:
    def type(self):
        return "This is a vehicle"

class Car(Vehicle):
    def wheels(self):
        return "Car has 4 wheels"

class Bike(Vehicle):
    def wheels(self):
        return "Bike has 2 wheels"

# Creating objects
car = Car()
bike = Bike()

print(car.type())   # From Vehicle
print(car.wheels()) # From Car
print(bike.type())  # From Vehicle
print(bike.wheels())# From Bike


# 14) Write a Python program to show multilevel inheritance. 

# 15) Write a Python program to show multiple
# 16) Write a Python program to show hierarchical inheritance. 
# 17) Write a Pythonprogram to show hybrid inheritance. 

class A:
    def methodA(self):
        return "Method A"

class B(A):
    def methodB(self):
        return "Method B"

class C(A):
    def methodC(self):
        return "Method C"

class D(B, C):  # Hybrid inheritance (Multiple + Hierarchical)
    def methodD(self):
        return "Method D"

# Creating an object
d = D()
print(d.methodA())  # From A
print(d.methodB())  # From B
print(d.methodC())  # From C
print(d.methodD())  # From D

# 18) Write a Python program to demonstrate the use ofsuper() in inheritance.

class Parent:
    def show(self):
        return "This is a method from Parent class"

class Child(Parent):
    def show(self):
        return super().show() + " - Overridden in Child class"

# Creating an object
child = Child()
print(child.show())

