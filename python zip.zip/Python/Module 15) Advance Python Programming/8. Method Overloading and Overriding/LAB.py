# Write Python programs to demonstrate method overloading and method overriding.
class MathOperations:
    def add(self, a, b=0, c=0):  # Using default arguments
        return a + b + c

# Creating an object
math_obj = MathOperations()

print(math_obj.add(5))         # Calls add(a)
print(math_obj.add(5, 10))     # Calls add(a, b)
print(math_obj.add(5, 10, 15)) # Calls add(a, b, c)

#Practical Examples: 19) Write a Python program to show method overloading.

class Animal:
    def speak(self):
        return "Animal makes a sound"

class Dog(Animal):
    def speak(self):  # Overriding the parent method
        return "Dog barks"

# Creating objects
animal = Animal()
dog = Dog()

print(animal.speak())  # Calls parent method
print(dog.speak())     # Calls overridden method in child class
