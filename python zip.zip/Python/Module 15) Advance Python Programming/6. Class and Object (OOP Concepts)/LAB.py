# Write a Python program to create a class and access its properties using an object.
# Defining a class
class Student:
    def __init__(self, name, age):
        self.name = name  # Attribute
        self.age = age    # Attribute

    def display_info(self):
        print(f"Student Name: {self.name}, Age: {self.age}")

# Creating an object of the class
student1 = Student("Khush", 22)

# Accessing class properties
print("Name:", student1.name)
print("Age:", student1.age)

# Calling a method
student1.display_info()


#Practical Examples: 11) Write a Python program to create a class and access the properties

# Global variable
global_var = "I am a global variable"

class Example:
    def __init__(self, value):
        self.instance_var = value  # Instance attribute

    def show_variables(self):
        local_var = "I am a local variable"  # Local variable
        print("Instance Variable:", self.instance_var)
        print("Local Variable:", local_var)
        print("Global Variable:", global_var)

# Creating an object
obj = Example("I am an instance variable")
obj.show_variables()