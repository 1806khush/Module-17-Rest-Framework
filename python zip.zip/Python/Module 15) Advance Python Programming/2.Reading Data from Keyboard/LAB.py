#Write a Python program to read a name and age from the user and print a formatted output.
name = input("Enter your name: ")
print("Hello,", name)
height = float(input("Enter your height in meters: "))
print("Your height is", height, "meters.")


#Practical Example: 2) Write a Python program to read a string, an integer, and a float from the keyboard and display them.
# Reading user input

user_string = input("Enter a string: ")
user_integer = int(input("Enter an integer: "))
user_float = float(input("Enter a float: "))

# Displaying the values
print("You entered:")
print("String:", user_string)f
print("Integer:", user_integer)
print("Float:", user_float)
