#Write a Python program to search for a word in a string using re.search().

import re

text = "Python is a powerful programming language."
pattern = "powerful"

# Search for the pattern anywhere in the text
match = re.search(pattern, text)

if match:
    print(f"Word found at position: {match.start()}")
else:
    print("Word not found.")

#Write a Python program to match a word in a string using re.match().


#Practical Examples: 23) Write a Python program to search for a word in a string using re.search(). 
import re

text = "Python is a powerful programming language."
pattern = "Python"

# Match the pattern at the beginning of the string
match = re.match(pattern, text)

if match:
    print("Word matches at the start of the string.")
else:
    print("No match at the start.")

