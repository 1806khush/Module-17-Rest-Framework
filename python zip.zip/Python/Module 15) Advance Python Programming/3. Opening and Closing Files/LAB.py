#Write a Python program to open a file in write mode, write some text, and then close it.

# Opening a file in write mode
file = open("example.txt", "w")

# Writing text to the file
file.write("Hello, this is a sample text written to the file.")

# Closing the file
file.close()

print("File has been created and text has been written successfully.") 

#Practical Example: 3) Write a Python program to create a file and write a string into i