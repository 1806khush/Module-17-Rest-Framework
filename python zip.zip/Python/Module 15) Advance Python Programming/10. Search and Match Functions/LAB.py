#Write a Python program to connect to an SQLite3 database, create a table, insert data, andfetch data.

import sqlite3

# Connect to SQLite database (or create one if it doesn't exist)
conn = sqlite3.connect("example.db")

# Create a cursor object
cursor = conn.cursor()

# Create a table
cursor.execute('''CREATE TABLE IF NOT EXISTS students (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    age INTEGER)''')

# Commit and close connection
conn.commit()
conn.close()

print("Database and table created successfully.")

#Practical Examples: 21) Write a Python program to create a database and a table usingSQLite3. 
#22) Write a Python program to insert data into an SQLite3 database and fetch it

import sqlite3

# Connect to SQLite database
conn = sqlite3.connect("example.db")
cursor = conn.cursor()

# Insert data
cursor.execute("INSERT INTO students (name, age) VALUES (?, ?)", ("Khush", 22))
cursor.execute("INSERT INTO students (name, age) VALUES (?, ?)", ("radhe", 25))

# Commit changes
conn.commit()

# Fetch and display data
cursor.execute("SELECT * FROM students")
rows = cursor.fetchall()

for row in rows:
    print(row)

# Close connection
conn.close()
