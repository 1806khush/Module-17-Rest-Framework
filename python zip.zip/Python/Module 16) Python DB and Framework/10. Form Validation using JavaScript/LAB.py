
django-admin startproject user_registration
cd user_registration
python manage.py startapp accounts
Step 2: Set Up URL Routing
In the user_registration project, set up the URL routing.

1. Edit the main urls.py (located in user_registration/urls.py)

python
Copy
Edit
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('register/', include('accounts.urls')),  # Include URLs for the accounts app
]
2. Create a urls.py in the accounts app

python
Copy
Edit
# accounts/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.register, name='register'),
]
Step 3: Create a View for the Registration Form
In the views.py of the accounts app, create the view for handling the registration page.

python
Copy
Edit
# accounts/views.py

from django.shortcuts import render

def register(request):
    return render(request, 'register.html')
Step 4: Create the HTML Form Template
Create a template for the registration form where we will include the JavaScript for validation.

Create the templates folder inside the accounts app.

Inside the templates folder, create register.html.

html
Copy
Edit
<!-- accounts/templates/register.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <script>
        // JavaScript function to validate the form
        function validateForm() {
            // Get the form elements
            var email = document.getElementById("email").value;
            var phone = document.getElementById("phone").value;
            var emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/; // Email regex pattern
            var phonePattern = /^[0-9]{10}$/; // Phone number pattern (10 digits)

            // Validate email
            if (!emailPattern.test(email)) {
                alert("Please enter a valid email address.");
                return false;
            }

            // Validate phone number
            if (!phonePattern.test(phone)) {
                alert("Please enter a valid phone number (10 digits).");
                return false;
            }

            // If all validations pass, allow form submission
            return true;
        }
    </script>
</head>
<body>

    <h1>User Registration</h1>
    <form method="POST" onsubmit="return validateForm()">
        {% csrf_token %}
        <div>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div>
            <label for="phone">Phone Number:</label>
            <input type="text" id="phone" name="phone" required>
        </div>
        <div>
            <button type="submit">Register</button>
        </div>
    </form>

</body>
</html>

