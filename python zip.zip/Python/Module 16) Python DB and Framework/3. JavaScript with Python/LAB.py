#Lab:
#• Create a Django project with JavaScript-enabled form validation.
#Practical Example: 3) Write a Django project where JavaScript is used to validate a patient
#registration form on the client side.

<!DOCTYPE html>
<html>
<head>
    <title>Drive Easy Car Rental</title>
    <script type="text/javascript">
        function validateForm() {
            var name = document.getElementById("name").value;
            var email = document.getElementById("email").value;
            var phone = document.getElementById("phone").value;

            if (name == "" || email == "" || phone == "") {
                alert("All fields must be filled out!");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
    <h1>Register for Car Rental</h1>
    <form action="/submit_form/" onsubmit="return validateForm()" method="post">
        {% csrf_token %}
        <label for="name">Name:</label>
        <input type="text" id="name" name="name"><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email"><br><br>

        <label for="phone">Phone:</label>
        <input type="tel" id="phone" name="phone"><br><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
