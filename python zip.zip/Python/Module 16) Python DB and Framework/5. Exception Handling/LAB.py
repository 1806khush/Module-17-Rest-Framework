Using venv to Create Isolated Environments
You can use the built-in venv module to create and manage virtual environments in Python 3. Here's how to use it:

Lab: Set up a Virtual Environment for a Django Project
Step 1: Install Python (if not already installed)
Ensure that Python is installed on your machine. You can check the version of Python by running:

bash
Copy
Edit
python --version
For Python 3.3+, venv should already be available. If you don't have Python installed, you can download it from the official Python website.

Step 2: Create a Virtual Environment
Navigate to your project directory where you want to set up the virtual environment (e.g., inside your Django project folder):

bash
Copy
Edit
cd path/to/your/project
Create the virtual environment using the venv module. Replace myenv with your preferred name for the environment:

bash
Copy
Edit
python -m venv myenv
This command will create a directory called myenv in your project directory. Inside this directory, it will install a local Python version along with pip, the package manager.

Step 3: Activate the Virtual Environment
After creating the virtual environment, you need to activate it to start using it.

On Windows:

bash
Copy
Edit
myenv\Scripts\activate
On macOS/Linux:

bash
Copy
Edit
source myenv/bin/activate
After activation, your terminal prompt will change to indicate that you're working inside the virtual environment. For example, it may look like:

ruby
Copy
Edit
(myenv) $ 
This means that any Python or pip commands you run will use the virtual environment’s Python installation and dependencies.

Step 4: Install Django in the Virtual Environment
Once your virtual environment is activated, you can use pip to install Django or any other packages you need for your project.

To install Django, run the following command:

bash
Copy
Edit
pip install django
This will install the latest version of Django inside your virtual environment, and the installation will not affect any other Python projects you have on your system.

Step 5: Verify Django Installation
You can verify that Django has been successfully installed by checking its version:

bash
Copy
Edit
python -m django --version
This should print the version of Django that was installed, confirming that it's correctly set up.