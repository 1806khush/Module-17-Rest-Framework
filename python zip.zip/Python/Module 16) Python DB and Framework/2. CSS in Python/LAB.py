#Lab:
#• Create a CSS file to style a basic HTML template in Django.
##r a doctor profile page.
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
}

h1 {
    color: #2c3e50;
    text-align: center;
}

.car-list {
    list-style-type: none;
    padding: 0;
}

.car-list li {
    background-color: #ecf0f1;
    margin: 10px;
    padding: 10px;
    border-radius: 5px;
}

