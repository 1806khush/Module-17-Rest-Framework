git commit -m "Initial commit of Doctor Finder project"
