# doctors/views.py

def payment_response(request):
    response = request.POST
    checksum = response.get('CHECKSUMHASH', '')
    
    # Verify checksum for security purposes
    is_verified = PaytmChecksum.verifySignature(response, settings.PAYTM_MERCHANT_KEY, checksum)
    
    if is_verified:
        # Check the payment status and update the database
        if response.get('STATUS') == 'TXN_SUCCESS':
            # Update payment status in the Appointment model
            appointment = Appointment.objects.get(id=response.get('ORDERID'))
            appointment.payment_status = 'Successful'
            appointment.save()
            return render(request, 'payment/payment_success.html', {'response': response})
        else:
            return render(request, 'payment/payment_failed.html', {'response': response})
    else:
        return render(request, 'payment/payment_failed.html', {'response': response})
