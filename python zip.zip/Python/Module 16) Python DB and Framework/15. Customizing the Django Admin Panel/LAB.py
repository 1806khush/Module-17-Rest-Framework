# doctors/admin.py

from django.contrib import admin
from .models import Doctor

class DoctorAdmin(admin.ModelAdmin):
    # List of fields to display in the admin list view
    list_display = ('name', 'specialty', 'phone_number', 'email', 'availability')

    # Adding filters to filter doctors based on specialty
    list_filter = ('specialty',)

    # Adding search functionality by name and specialty
    search_fields = ('name', 'specialty')

    # Display doctor availability in a more readable format
    def availability(self, obj):
        return f"Available: {obj.availability}"

    # Make the availability field editable in the list view
    availability.admin_order_field = 'availability'  # Optional: Sorting by availability
    availability.short_description = 'Doctor Availability'

# Register the model with the custom admin class
admin.site.register(Doctor, DoctorAdmin)
