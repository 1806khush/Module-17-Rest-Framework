<!-- find_doctor/templates/profile.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctor Profile</title>
</head>
<body>
    <h1>Doctor Profile</h1>
    <h2>{{ name }}</h2>
    <p>Specialty: {{ specialty }}</p>
    <nav>
        <ul>
            <li><a href="{% url 'home' %}">Home</a></li>
            <li><a href="{% url 'profile' %}">Doctor Profile</a></li>
            <li><a href="{% url 'contact' %}">Contact Us</a></li>
        </ul>
    </nav>
</body>
</html>
