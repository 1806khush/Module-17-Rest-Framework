<!-- templates/doctor_map.html -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Locations</title>
    <script src="https://maps.googleapis.com/maps/api/js?key={{ google_maps_api_key }}&callback=initMap" async defer></script>
</head>
<body>
    <h1>Doctor Locations</h1>
    <div id="map" style="height: 500px;"></div>

    <script>
        var map;

        function initMap() {
            map = new google.maps.Map(document.getElementById('map'), {
                center: {lat: 37.7749, lng: -122.4194},  // Default to San Francisco
                zoom: 10
            });

            {% for doctor in doctors %}
                var marker = new google.maps.Marker({
                    position: {lat: {{ doctor.latitude }}, lng: {{ doctor.longitude }}},
                    map: map,
                    title: '{{ doctor.name }}'
                });
            {% endfor %}
        }
    </script>
</body>
</html>
