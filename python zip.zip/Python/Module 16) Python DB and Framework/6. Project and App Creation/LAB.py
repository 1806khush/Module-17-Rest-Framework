# Step 1: Create the Django Project
django-admin startproject hospital_system
cd hospital_system

# Step 2: Create the Doctor App
python manage.py startapp doctor

# Step 3: Define the Doctor Model (in doctor/models.py)
# (Code provided above)

# Step 4: Register the Model in Admin (in doctor/admin.py)
# (Code provided above)

# Step 5: Create a View to Display Doctor Profiles (in doctor/views.py)
# (Code provided above)

# Step 6: Define URLs for the Doctor App (in doctor/urls.py)
# (Code provided above)

# Step 7: Create Template (in doctor/templates/doctor/doctor_list.html)
# (Code provided above)

# Step 8: Run Migrations
python manage.py makemigrations
python manage.py migrate

# Step 9: Create a Superuser (Optional)
python manage.py createsuperuser

# Step 10: Run the Development Server
python manage.py runserver
