# doctors/views.py

from django.shortcuts import render
from .models import Doctor

def add_doctor(request):
    if request.method == "POST":
        name = request.POST['name']
        specialty = request.POST['specialty']
        phone_number = request.POST['phone_number']
        email = request.POST['email']
        address = request.POST['address']

        doctor = Doctor(name=name, specialty=specialty, phone_number=phone_number, email=email, address=address)
        doctor.save()  # Save the new doctor to the database

        return render(request, 'doctor_added.html', {'doctor': doctor})
    return render(request, 'add_doctor.html')
