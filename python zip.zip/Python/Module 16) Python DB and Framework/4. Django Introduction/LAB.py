#Lab:
#• Write a short project using Django’s built-in tools to render a simple webpage.
#Practical Example: 4) Write a Python program to create a Django project and understand its
#directory structure
from django.shortcuts import render

# Create a view for the home page
def home(request):
    return render(request, 'home.html')
