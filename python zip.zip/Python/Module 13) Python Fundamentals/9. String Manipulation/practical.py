#Write a Python program to demonstrate string slicing.

my_string = "Hello, World!"
print(my_string[7:13])  # Slices from index 7 to 12

#Write a Python program that manipulates and prints strings using various string methods.

my_string = "   Hello, Python World!   "
print(my_string.upper())  # Uppercase
print(my_string.lower())  # Lowercase
print(my_string.strip())  # Stripped spaces
print(my_string.replace("Python", "Java"))  # Replaced substring
