print('hello world')
print('khush')