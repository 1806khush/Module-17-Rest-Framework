'''
l = [1,2,3,"khush",1.45,True,False]

l.append(100) #add at last 

l1 = l.copy() #add same list to another variable

print(l.count(1))

l.extend([500,200,300]) #add whole list

l.insert(4,"hi") #insert value at specific index

l.pop(3) #remove 3rd index value

l.remove(2) # remove specific value

l.reverse() # reverse the whole list

print(l)

'''
'''
n = int(input('enter number :'))
l = []
even = []
odd = []
for i in range(1,n+1):
    l.append(i)
    if i%2 == 0:
        even.append(i)
    else:
        odd.append(i)

print(l,even,odd)

'''    
def fun1(): 
    n = int(input('enter your list number:'))
    l = []
    for i in range(1,n+1):
        
        new_value = input('enter number :')
        
        l.append(new_value)
        
    print(l)
fun1()
'''
l = [1,2,3]
l1 = [6,7,8]
d = {}

#print(d.fromkeys(l))

for i in range(len(l)):
    d[l[i]] = l1[i]

print(d)
'''
t = (1,2,3,"Hello",1.64,1.25)

print(type(t))

print(t.count(1))
print(t.index(1.64))

l1=list(t)

l1.append(100)
print(l1)

t1= tuple(l1)
print(t1)