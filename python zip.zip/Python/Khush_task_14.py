# 3) Multiple inheritance
#   A         B
#        !
#        C
'''
class A:
    def fun1(self):
        l = ["grape","orange","pineapple"]
        print(l)
    
    def fun2(self):
        n = int(input("enter the no:"))
        for i in range(1,n+1):
            print("*"*i)
    
    
class B:
    def fun3(self):
        d = {1:"how",2:"are",3:"You",4:"dude"}
        print(d)
        
class C(A,B):
    def fun4(self):
        n = int(input("Enter Number : "))
        n1 = 0
        n2 = 1

        print(n1)
        print(n2)

        for i in range(3,n+1):
            n3=n1+n2
            print(n3)
            n1=n2
            n2=n3

obj = C()
obj.fun1()
obj.fun2()
obj.fun3()
obj.fun4()

'''


# 4) HIERARCHICAL INHERITANCE

#           A

#           !
#      B        c

'''
class A:
    def speak(self):
        print("This is an animal.")

class B(A):
    def speak1(self):
        print("The dog says: Woof!")


class C(A):
    def speak2(self):
        print("The cat says: Meow!")
        
obj = C()

obj.speak()
obj.speak()
obj.speak2()
'''

# 5) Hybrid INHERITANCE

# A
# !
# B        C
#     !
#     D
'''
class A:
    def speak(self):
        print("This is an animal.")

class B(A):
    def speak(self):
        print("The dog says: Woof!")

class C(A):
    def speak(self):
        print("The cat says: Meow!")


class D(A):
    def speak(self):
        super().speak()
        print("The cow says: Moo!")

obj = D()
obj.speak()

'''

# 6) POLYMORPHISM  - IT IS THE ABILITY OF OBJECTS TO TAKE ON DIFFERENT FORMS OR BEHAVE IN DIFFERENT WAYS DDEPENDING ON THE CONTEXT IN WHICH THEY ARE USED


#  POLY-> MANY
#  MORPHISM -> FORMS  

#   MANY FORMS

#1)OVER LOADING

#2)OVER RIDING

'''
class C():
    def speak(self):
        print("The cat says: Meow!")


class D(C):
    def speak(self):
        super().speak()
        print("The cow says: Moo!")

obj = D()
obj.speak()

'''

        
'''
class A:
    def speak(self):
        super().speak()
        print("This is an animal.")

class B:
    def speak(self):
        print("The dog says: Woof!")

class C(A,B):
    def speak(self):
        super().speak()
        print("The cat says: Meow!")

obj = C()
obj.speak()

'''
