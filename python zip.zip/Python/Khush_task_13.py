import random
class A:
    def __init__(self):
        self.total = 0

    def fun1(self):
        print("You have selected Fries!!")
        qty_fries = int(input("Enter the number of fries you want: "))
        price = 80  
        self.total += qty_fries * price
        print(f"Added {qty_fries} fries. Subtotal: {self.total}")

class B(A):
    def fun2(self):
        print("You have selected Burger!!")
        qty_burger = int(input("Enter the number of Burgers you want: "))
        price = 200  
        self.total += qty_burger * price
        print(f"Added {qty_burger} burgers. Subtotal: {self.total}")

class C(B):
    def fun3(self):
        print("You have selected Pizza!!")
        qty_pizza = int(input("Enter the number of Pizzas you want: "))
        price = 800  
        self.total += qty_pizza * price
        print(f"Added {qty_pizza} pizzas. Subtotal: {self.total}")

class D(C):
    def generate_otp(self):
        return random.randint(100,200)

    def verify_otp(self, otp):
        user_otp = int(input("Enter the OTP sent to your device: "))
        return user_otp == otp

    def fun4(self):
        
        otp = self.generate_otp()
        
        print("Your OTP is :",otp)
        
        if not self.verify_otp(otp):
            print("Invalid OTP. Transaction cancelled.")
            return
        gst = self.total * 0.09  
        sgst = self.total * 0.09  
        final_total = self.total + gst + sgst
        print("---------- Final Bill ----------")
        
        print(f"Subtotal: {self.total}")
        
        print(f"GST (9%): {gst}")
        
        print(f"SGST (9%): {sgst}")
        
        print(f"Total Amount: {final_total}")
        
        print("Thank You!!!")


obj = D()

while True:
    menu = """
    Press 1 Fries
    Press 2 Burger
    Press 3 Pizza
    Press 4 Exit
    """
    print(menu)
    try:
        
        choice = int(input("Enter Your Choice: "))
        
    except ValueError:
        
        print("Please select values between 1 and 4.")
        
        continue

    if choice == 1:
        
        mobile_no = int(input("Enter your mobile no of upto 10 digits :"))
        obj.fun1()
        
    elif choice == 2:
        
        mobile_no = int(input("Enter your mobile no of upto 10 digits :"))
        obj.fun2()
        
    elif choice == 3:
        
        mobile_no = int(input("Enter your mobile no of upto 10 digits :"))
        obj.fun3()
        
    elif choice == 4:

        obj.fun4()
        break
    
    else:
        print("Invalid Choice!!")
    
    
    
