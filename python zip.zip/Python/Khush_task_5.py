# STRINGS / SLICING.
'''
s = "hello this is python programming"
print(s[5:29:3]) 
print(s[:15:2])  
print(s[12:28:2]) 
print(s[6::4])    
print(s[12:30:1]) 
print(len(s))

s= "python programming"
print(s[-15:-2:3])
print(s[::-1])	    
print(s[:-5:2])    
print(s[-12::4])   
'''
s= input("enter your string :")

if len(s)%2==0:
    print(s)

else:
    mid = int(len(s)/2)
    print(s[mid-1] + s[mid] + s[mid+1]) 