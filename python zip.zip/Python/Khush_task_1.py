print("Welcome to Ticket counter")

print("Press 1 for Rajhansh")
print("Press 2 for PVR")
print("Press 3 for Cinepolix")

user = int(input("Select your cinema location (1/2/3): "))

cgst_rate = 0.06  
sgst_rate = 0.06  

if user == 1:  
    
    print("Recliner seat  =  Rs300")
    print("Executive seat =  Rs200")
    print("Regular seat   =  Rs150")

    choice = int(input("Enter your choice (1 for Recliner, 2 for Executive, 3 for Regular): "))
    
    if choice == 1:
        print("You have selected Recliner seat")
        qty = int(input("Enter the number of seats you want: "))
        price = 300 * qty
        print("Temp bill = Rs", price)
        
        cgst = price * cgst_rate
        sgst = price * sgst_rate
        total_bill = price + cgst + sgst
        
        print(f"CGST (6%) = Rs {cgst}")
        print(f"SGST (6%) = Rs {sgst}")
        print("TOTAL BILL = Rs", total_bill)
    
    elif choice == 2:
        print("You have selected Executive seat")
        qty = int(input("Enter the number of seats you want: "))
        price = 200 * qty
        print("Temp bill = Rs", price)
        
        cgst = price * cgst_rate
        sgst = price * sgst_rate
        total_bill = price + cgst + sgst
        
        print(f"CGST (6%) = Rs {cgst}")
        print(f"SGST (6%) = Rs {sgst}")
        print("TOTAL BILL = Rs", total_bill)
    
    elif choice == 3:
        print("You have selected Regular seat")
        qty = int(input("Enter the number of seats you want: "))
        price = 150 * qty
        print("Temp bill = Rs", price)
        
        cgst = price * cgst_rate
        sgst = price * sgst_rate
        total_bill = price + cgst + sgst
        
        print(f"CGST (6%) = Rs {cgst}")
        print(f"SGST (6%) = Rs {sgst}")
        print("TOTAL BILL = Rs", total_bill)

elif user == 2:  
    
    print("Recliner seat  =  Rs800")
    print("Executive seat =  Rs500")
    print("Regular seat   =  Rs250")

    choice1 = int(input("Enter your choice (1 for Recliner, 2 for Executive, 3 for Regular): "))
    
    if choice1 == 1:
        print("You have selected Recliner seat")
        qty = int(input("Enter the number of seats you want: "))
        price = 800 * qty
        print("Temp bill = Rs", price)
        
        cgst = price * cgst_rate
        sgst = price * sgst_rate
        total_bill = price + cgst + sgst
        
        print(f"CGST (6%) = Rs {cgst}")
        print(f"SGST (6%) = Rs {sgst}")
        print("TOTAL BILL = Rs", total_bill)
    
    elif choice1 == 2:
        print("You have selected Executive seat")
        qty = int(input("Enter the number of seats you want: "))
        price = 500 * qty
        print("Temp bill = Rs", price)
        
        cgst = price * cgst_rate
        sgst = price * sgst_rate
        total_bill = price + cgst + sgst
        
        print(f"CGST (6%) = Rs {cgst}")
        print(f"SGST (6%) = Rs {sgst}")
        print("TOTAL BILL = Rs", total_bill)
    
    elif choice1 == 3:
        print("You have selected Regular seat")
        qty = int(input("Enter the number of seats you want: "))
        price = 250 * qty
        print("Temp bill = Rs", price)
        
        cgst = price * cgst_rate
        sgst = price * sgst_rate
        total_bill = price + cgst + sgst
        
        print(f"CGST (6%) = Rs {cgst}")
        print(f"SGST (6%) = Rs {sgst}")
        print("TOTAL BILL = Rs", total_bill)

elif user == 3:  
    
    print("Recliner seat  =  Rs600")
    print("Executive seat =  Rs400")
    print("Regular seat   =  Rs100")

    choice2 = int(input("Enter your choice (1 for Recliner, 2 for Executive, 3 for Regular): "))
    
    if choice2 == 1:
        print("You have selected Recliner seat")
        qty = int(input("Enter the number of seats you want: "))
        price = 600 * qty
        print("Temp bill = Rs", price)
        
        cgst = price * cgst_rate
        sgst = price * sgst_rate
        total_bill = price + cgst + sgst
        
        print(f"CGST (6%) = Rs {cgst}")
        print(f"SGST (6%) = Rs {sgst}")
        print("TOTAL BILL = Rs", total_bill)
    
    elif choice2 == 2:
        print("You have selected Executive seat")
        qty = int(input("Enter the number of seats you want: "))
        price = 400 * qty
        print("Temp bill = Rs", price)
        
        cgst = price * cgst_rate
        sgst = price * sgst_rate
        total_bill = price + cgst + sgst
        
        print(f"CGST (6%) = Rs {cgst}")
        print(f"SGST (6%) = Rs {sgst}")
        print("TOTAL BILL = Rs", total_bill)
    
    elif choice2 == 3:
        print("You have selected Regular seat")
        qty = int(input("Enter the number of seats you want: "))
        price = 100 * qty
        print("Temp bill = Rs", price)
        
        cgst = price * cgst_rate
        sgst = price * sgst_rate
        total_bill = price + cgst + sgst
        
        print(f"CGST (6%) = Rs {cgst}")
        print(f"SGST (6%) = Rs {sgst}")
        print("TOTAL BILL = Rs", total_bill)

else:
    print("ERROR!!! Invalid selection.")
    
    
    
#1
"""
List = ['apple', 'banana', 'mango']

for fruit in List:
    print(fruit)
"""
#2
'''
List = ['apple', 'banana', 'mango']

for fruit in List:
    print(len(fruit))
'''
#3
'''
List = ['apple', 'banana', 'mango']

food = 'apple' or 'banana' or 'mango'
for fruit in List:
    if fruit == food:
        print(f"'{food}' found in the list!")
        found = True
        break
    else:
        print('error')
        break
'''
#4
'''
i=1
n=5
for i in range(1,n+1):
    for j in range(i):
        print('*',end='')
    print()
'''
