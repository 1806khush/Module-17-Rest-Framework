def fun1(n):
    remainder = 0
    reverse = 0
    
    while (n!=0):
        remainder = n%10
        reverse = reverse*10 + remainder
        
        n = n//10
    print("reversed number is :",reverse)
    
def fun2():
    n = int(input("enter your number :"))
    for i in range(1,n+1):
        print(f"{i}"*i)
    
def fun3():
    n = int(input("enter your number1 :"))
    n1 = int(input("enter your number2:"))
    
    print("addition is :",n+n1)

def fun4(n):
    
    n = int(input("enter your number1 :"))
    n1 = int(input("enter your number2:"))
    
    return n-n1
            
while True:
    menu = """
    
    press 1 for Reversed number
    press 2 for raws
    press 3 for addtion of 2 numbers
    press 4 for exit   
    press 5 for subraction 
    """
    print(menu)
    choice = int(input("enter your choice :"))
    if choice == 1:
        n=int(input("enter your number :"))
        fun1(n)
    elif choice == 2:
        fun2()
        
    elif choice == 3:
        fun3()
        
    elif choice == 4:
        print("exit")
        break
    
    elif choice == 5:
        n = int(input("enter your number :"))
        answer = fun4(n)
        print("subraction is :",answer)
        
    else:
        print("Invalid option!!")
        break
    