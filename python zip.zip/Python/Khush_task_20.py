from Khush_task_19 import *

mydb = pymysql.connect(host = "localhost", user = "root", password = "")
mycursor = mydb.cursor()

mycursor.execute("create database if not exists python1")
mydb.commit()

mydb = pymysql.connect(host = "localhost", user = "root", password = "", database = "python1")
mycursor = mydb.cursor()

mycursor.execute("create table if not exists person(id int primary key auto_increment,name varchar(80),subject varchar(80))")
mydb.commit()

while True:
    
    menu = """
    press 1 for Insert Data
    press 2 for Update Data
    press 3 for Delete Data
    press 4 for Fetch  Data
    press 5 for Exit    
    
    
"""
    print(menu)
    
    choice = int(input("Enter your choice :"))
    
    if choice == 1:
        
        name = input("Enter your name : ")
        subject = input("Enter Subject :")
        
        query = "insert into person (name,subject) values ('%s','%s')"
        
        args = (name,subject)
        
        mycursor.execute(query % args)
        mydb.commit()
        print("Data Inserted!!!")
        
        
    elif choice == 2:
        
        id = int(input("Enter Id you want to update"))
        name = input("Enter your name : ")
        subject = input("Enter Subject :")
        
        query = "update person set name='%s',subject = '%s' where id = '%s'"
        
        args = (name,subject,id)
        
        mycursor.execute(query % args)
        mydb.commit()
        print("Data Updated!!!")
        
    elif choice == 3:
        
        id = int(input("Enter Id you want to update"))

        
        query = "delete from person where id = '%s'"
        
        args = (id)
        
        mycursor.execute(query % args)
        mydb.commit()
        print("Data Deleted!!!")
        
    elif choice == 4:
        
        query = "select * from person'"
        
        mycursor.execute(query)
        
        data = mycursor.fetchall()
        print(data)
        
        print("Data fetched!!!")
        
    elif choice ==5:
        print("Thank you!!")
        break
    
    else:
        print("Invalid input Please try again!!!")
        break
    
    
    